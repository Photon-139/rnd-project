#!/bin/bash
#SBATCH --job-name=vitb_lora_2
#SBATCH --output=vitb_lora_2_%j.out
#SBATCH --error=vitb_lora_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=24:00:00
#SBATCH --partition=mig45g

# VIT-B LoRA PLACEMENT (paired: library + scratch). One experiment per job (5 seeds paired is ~10-13 h):
#   EXPS="lora_attn_r8_L6-11" sbatch --dependency=afterok:<gate job id> job_vitb_lora_2.sh
# It refuses to start unless results_smoke_vitb/gate_certificate.json certifies the code currently on disk.
# Everything the result needs is produced here, in one job, from the adapters THIS job trains
# (no retraining, no separate catch-up job):
#   1. training runs: each experiment x seeds, paired; each run exports its adapter
#      (results_v2/<exp>/<impl>_seed<N>_adapter.pt)
#   2. at seed 42, on those TRAINED adapters:
#      - memory profiler, both implementations: train-step decomposition + batch-size sweep, and inference
#        memory/latency merged vs unmerged (results_v2_profile/)
#      - merge study on the library adapter, applied to both implementations: merged vs unmerged outputs, library
#        vs scratch, 100 merge/unmerge cycles, merge cost, test accuracy unmerged / merged / after cycles
#        (results_v2_merge/)
# Outputs go to results_v2* because the all-blocks reference rerun (lora_attn_r8) has the same file names as the
# archived ViT-B runs: a separate folder means no copy or sync can ever overwrite the archive.
# Rerun-safe: existing outputs are skipped. A seed with only one implementation's result (job killed between the
# two) is moved to results_v2/<exp>/orphaned_<job id>/ and rerun paired. Runs from the directory you submit from
# (VisionTransformer_2).
set -euo pipefail

SEEDS="${SEEDS:-42 123 456 789 1024}"
EXPS="${EXPS:?set EXPS, e.g. EXPS=lora_attn_r8_L6-11 (one experiment per job: 5 paired seeds take ~10-13 h)}"
RES=results_v2
PROF=results_v2_profile
MERGE=results_v2_merge

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS | seeds: $SEEDS"

echo "=== 0. precautions: gate certificate for this exact code, then verify-only ==="
$PY tests/check_vitb_gate.py --verify-certificate
$PY tests/check_vitb_gate.py --check-existing $EXPS --dirs $RES $PROF $MERGE
$PY run.py --verify-only -s 42 -e $EXPS

echo "=== 1. paired training ==="
for exp in $EXPS; do
  for seed in $SEEDS; do
    lib="$RES/$exp/library_seed${seed}.json"
    scr="$RES/$exp/scratch_seed${seed}.json"
    if [ -f "$lib" ] && [ -f "$scr" ]; then echo "skip $exp seed $seed (both results exist)"; continue; fi
    if [ -f "$lib" ] || [ -f "$scr" ]; then
      # Paired runs train both implementations from one build; a lone result cannot be completed on its own.
      orphan="$RES/$exp/orphaned_${SLURM_JOB_ID:-local}"
      echo "NOTE: $exp seed $seed has only one implementation's result; moving it to $orphan/ and rerunning paired"
      mkdir -p "$orphan"
      for f in "$RES/$exp/"*_seed${seed}.json "$RES/$exp/"*_seed${seed}_adapter.pt; do
        if [ -e "$f" ]; then mv "$f" "$orphan/"; fi
      done
    fi
    $PY run.py -e "$exp" -s "$seed" --impl paired --results-dir $RES --checkpoint-dir checkpoints_v2
  done
done

echo "=== 2. profiler + merge study on the trained seed-42 adapters ==="
for exp in $EXPS; do
  for impl in library scratch; do
    adapter="$RES/$exp/${impl}_seed42_adapter.pt"
    if [ ! -f "$adapter" ]; then
      # Never fall back to a perturbed adapter: the numbers would silently describe an untrained model.
      echo "ERROR: $adapter missing (seed 42 not trained, or its adapter export failed); not profiling $exp"
      exit 1
    fi
    for mode in train inference; do
      out="$PROF/$exp/${impl}_seed42_${mode}.json"
      if [ -f "$out" ]; then echo "skip $out"; continue; fi
      $PY profile_memory.py --experiment "$exp" --impl "$impl" --mode "$mode" --seed 42 \
          --adapter "$adapter" --out $PROF
    done
  done
  out="$MERGE/$exp/seed42.json"
  if [ -f "$out" ]; then echo "skip $out"; else
    $PY merge_study.py --experiment "$exp" --seed 42 --adapter "$RES/$exp/library_seed42_adapter.pt" --eval-test \
        --out $MERGE
  fi
done

echo "VITB LORA DONE"
for exp in $EXPS; do ls -la "$RES/$exp/" "$PROF/$exp/" "$MERGE/$exp/" || true; done
