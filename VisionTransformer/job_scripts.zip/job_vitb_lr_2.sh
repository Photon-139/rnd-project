#!/bin/bash
#SBATCH --job-name=vitb_lr_2
#SBATCH --output=vitb_lr_2_%j.out
#SBATCH --error=vitb_lr_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=24:00:00
#SBATCH --partition=mig45g

# VIT-B LEARNING-RATE CHECK (library only). Full fine-tuning below the earlier range and LoRA either side of 1e-4,
# trained with the same code as the placement runs so that every rate is compared within one code version:
#   EXPS="baseline_lr3e-6 baseline_lr1e-5" sbatch --dependency=afterok:<gate job id> job_vitb_lr_2.sh
#   EXPS="lora_attn_r8_lr3e-5 lora_attn_r8_lr3e-4 lora_attn_r8_lr1e-3" sbatch --dependency=afterok:<gate> job_vitb_lr_2.sh
# baseline_lr1e-5 is the earlier best full-fine-tuning rate, rerun here because its archived runs are from the
# pre-refactor code; LoRA at 1e-4 already exists in results_v2/lora_attn_r8 (this code).
# Library only: the question is the rate, not the implementation. ViT-B library runs train no scratch twin, so
# the paired equivalence check runs here once per experiment (run.py --verify-only) before any training.
# Only training results: the rate does not change any tensor shape, so memory, latency and merge behaviour are
# those already measured for baseline and lora_attn_r8 (profiler and merge study are not repeated).
# It refuses to start unless results_smoke_vitb/gate_certificate.json certifies the code currently on disk.
# Outputs go to results_v2/ (never results/: baseline_lr1e-5 has the same file names as the archived run).
# Rerun-safe: existing outputs are skipped. Runs from the directory you submit from (VisionTransformer_2).
set -euo pipefail

SEEDS="${SEEDS:-42 123 456}"
EXPS="${EXPS:?set EXPS, e.g. EXPS=\"baseline_lr3e-6 baseline_lr1e-5\"}"
RES=results_v2

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS | seeds: $SEEDS"

echo "=== 0. precautions: gate certificate for this exact code, then verify-only (paired) ==="
$PY tests/check_vitb_gate.py --verify-certificate
$PY tests/check_vitb_gate.py --check-existing $EXPS --dirs $RES results_v2_profile results_v2_merge
$PY run.py --verify-only -s 42 -e $EXPS

echo "=== 1. training (library) ==="
for exp in $EXPS; do
  for seed in $SEEDS; do
    if [ -f "$RES/$exp/library_seed${seed}.json" ]; then echo "skip $exp seed $seed (result exists)"; continue; fi
    $PY run.py -e "$exp" -s "$seed" --impl library --results-dir $RES --checkpoint-dir checkpoints_v2
  done
done

echo "VITB LR DONE"
for exp in $EXPS; do ls -la "$RES/$exp/" || true; done
