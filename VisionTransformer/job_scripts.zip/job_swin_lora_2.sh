#!/bin/bash
#SBATCH --job-name=swin_lora_2
#SBATCH --output=swin_lora_2_%j.out
#SBATCH --error=swin_lora_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=24:00:00
#SBATCH --partition=mig45g

# SWIN-B LoRA (job B), library only. Submit with --dependency=afterok:<gate job id>; it also refuses to
# start unless results_smoke/gate_certificate.json certifies the code currently on disk.
# Everything the result needs is produced here, in one job, from the adapters THIS job trains
# (no retraining, no separate catch-up job):
#   1. training runs: each LoRA experiment x seeds; each run exports its adapter
#      (results/<exp>/library_seed<N>_adapter.pt)
#   2. at seed 42, on that TRAINED adapter:
#      - memory profiler: train-step decomposition + batch-size sweep, and inference memory/latency
#        merged vs unmerged (results_profile/)
#      - merge study: merged vs unmerged outputs, 100 merge/unmerge cycles, merge cost, and test
#        accuracy unmerged / merged / after cycles (results_merge_trained/)
# MLP-only is optional: EXPS="swinb_lora_attn_r8 swinb_lora_attn_mlp_r8 swinb_lora_mlp_r8" sbatch ...
# Rerun-safe: existing outputs are skipped. Runs from the directory you submit from (VisionTransformer_2).
set -euo pipefail

SEEDS="${SEEDS:-42 123 456}"
EXPS="${EXPS:-swinb_lora_attn_r8 swinb_lora_attn_mlp_r8}"

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS | seeds: $SEEDS"

echo "=== 0. precautions: gate certificate for this exact code, then verify-only ==="
$PY tests/check_swin_gate.py --verify-certificate
$PY tests/check_swin_gate.py --check-existing $EXPS
$PY run.py --verify-only -s 42 -e $EXPS

echo "=== 1. training ==="
for exp in $EXPS; do
  for seed in $SEEDS; do
    if [ -f "results/$exp/library_seed${seed}.json" ]; then echo "skip $exp seed $seed (result exists)"; continue; fi
    $PY run.py -e "$exp" -s "$seed" --impl library
  done
done

echo "=== 2. profiler + merge study on the trained seed-42 adapters ==="
for exp in $EXPS; do
  adapter="results/$exp/library_seed42_adapter.pt"
  if [ ! -f "$adapter" ]; then
    # Never fall back to a perturbed adapter: the numbers would silently describe an untrained model.
    echo "ERROR: $adapter missing (seed 42 not trained, or its adapter export failed); not profiling $exp"
    exit 1
  fi
  for mode in train inference; do
    out="results_profile/$exp/library_seed42_${mode}.json"
    if [ -f "$out" ]; then echo "skip $out"; continue; fi
    $PY profile_memory.py --experiment "$exp" --impl library --mode "$mode" --seed 42 \
        --adapter "$adapter" --out results_profile
  done
  out="results_merge_trained/$exp/seed42.json"
  if [ -f "$out" ]; then echo "skip $out"; else
    $PY merge_study.py --experiment "$exp" --seed 42 --adapter "$adapter" --eval-test --out results_merge_trained
  fi
done

echo "LORA DONE"
for exp in $EXPS; do ls -la "results/$exp/" "results_profile/$exp/" "results_merge_trained/$exp/" || true; done
