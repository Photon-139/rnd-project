#!/bin/bash
#SBATCH --job-name=vitb_gap_2
#SBATCH --output=vitb_gap_2_%j.out
#SBATCH --error=vitb_gap_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=14:00:00
#SBATCH --partition=mig45g

# VIT-B GAP RUNS for the final report (library training only, one experiment per job). NO CODE CHANGE: the
# certified code is used as it is, so no new gate is needed and the runs come from exactly the code that
# produced the latest ViT-B / DeiT-B runs.
#   G1. Full fine-tuning at learning rate 3e-5 (missing from the ViT-B grid; Swin-B has it), 5 seeds, ~7 h:
#       EXP=baseline_lr1e-5 LR=3e-5 RES=results_v2_lr3e-5 SEEDS="42 123 456 789 1024" sbatch job_vitb_gap_2.sh
#       The registry has no ViT-B full-FT entry at 3e-5, so the rate is set with run.py --lr (recorded in each
#       JSON as config.lr). The files are therefore named after the registry entry (baseline_lr1e-5) and the
#       folder name (results_v2_lr3e-5) carries the real rate.
#   G3. Attention LoRA on all blocks, rerun with the code that trained blocks 3-11, 3 seeds, ~3.5 h:
#       EXP=lora_attn_r8 RES=results_v3 SEEDS="42 123 456" sbatch job_vitb_gap_2.sh
# RES must be a NEW folder: results/ and results_v2/ already hold runs with the same file names.
#   0. precautions: the ViT-B gate certificate for this exact code, outputs already in RES made by other code,
#      run.py --verify-only (paired), then a 1-epoch smoke run into results_smoke_gap_<EXP>/ whose JSON must
#      record the requested rate
#   1. training, library, one run per seed
#   2. every result JSON in RES must record the requested rate
# Rerun-safe: existing outputs are skipped (resubmit the same command after a timeout). This script is not
# hashed by the certificate (as job_memory_sweep_2.sh). Runs from the directory you submit from.
set -euo pipefail

EXP="${EXP:?set EXP (one registered experiment), e.g. EXP=baseline_lr1e-5}"
RES="${RES:?set RES (a new results folder), e.g. RES=results_v2_lr3e-5}"
SEEDS="${SEEDS:-42 123 456}"
LR="${LR:-}"                                  # empty = the registry's rate
MIN_SMOKE_ACC="${MIN_SMOKE_ACC:-20}"          # % after 1 epoch; only catches a run that does not learn
SMOKE="results_smoke_gap_${EXP}"
CKPT="checkpoints_gap_${EXP}"
case "$RES" in results|results/|results_v2|results_v2/)
  echo "REFUSING: RES=$RES already holds runs with the same file names; use a new folder."; exit 1;;
esac
LR_ARG=""
if [ -n "$LR" ]; then LR_ARG="--lr $LR"; fi

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiment: $EXP | lr: ${LR:-registry} | seeds: $SEEDS | results: $RES"

# Every result JSON of $EXP in folder $1 must record the requested rate (the registry's when LR is empty);
# with a second argument it is the smoke check: exactly 1 epoch and a model that learned.
check_lr() {
  $PY - "$1" "$EXP" "$LR" "${2:-}" <<'EOF'
import glob, json, sys
folder, exp, lr, smoke_min = sys.argv[1:5]
from experiments import EXPERIMENTS
want = float(lr) if lr else EXPERIMENTS[exp].lr
files = sorted(glob.glob(f"{folder}/{exp}/library_seed*.json"))
if not files:
    sys.exit(f"FAILED: no result JSON in {folder}/{exp}")
bad = 0
for f in files:
    j = json.load(open(f))
    got, acc, n = j["config"]["lr"], j["metrics"]["test_acc"], len(j["per_epoch"])
    ok = abs(got - want) <= 1e-12 * max(1.0, abs(want))
    if smoke_min:
        ok = ok and n == 1 and acc >= float(smoke_min)
    print(f"  [{'ok' if ok else 'FAILED'}] {f}: lr {got:g} (want {want:g}), {n} epoch(s), test accuracy {acc:.2f}%")
    bad += not ok
sys.exit(1 if bad else 0)
EOF
}

echo "=== 0. precautions: gate certificate for this exact code, existing outputs, verify-only, smoke run ==="
$PY tests/check_vitb_gate.py --verify-certificate
$PY tests/check_vitb_gate.py --check-existing $EXP --dirs $RES no_profile_dir no_merge_dir
$PY run.py --verify-only -s 42 -e $EXP
rm -rf "$SMOKE" "checkpoints_smoke_gap_${EXP}"
$PY run.py -e "$EXP" -s 42 --impl library $LR_ARG --max-epochs 1 --results-dir "$SMOKE" \
    --checkpoint-dir "checkpoints_smoke_gap_${EXP}"
check_lr "$SMOKE" "$MIN_SMOKE_ACC"

echo "=== 1. training (library) ==="
for seed in $SEEDS; do
  if [ -f "$RES/$EXP/library_seed${seed}.json" ]; then echo "skip $EXP seed $seed (result exists)"; continue; fi
  $PY run.py -e "$EXP" -s "$seed" --impl library $LR_ARG --results-dir "$RES" --checkpoint-dir "$CKPT"
done

echo "=== 2. recorded learning rate of every result ==="
check_lr "$RES"

echo "VITB GAP DONE"
ls -la "$RES/$EXP/" || true
