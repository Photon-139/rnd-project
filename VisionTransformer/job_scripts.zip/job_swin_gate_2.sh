#!/bin/bash
#SBATCH --job-name=swin_gate_2
#SBATCH --output=swin_gate_2_%j.out
#SBATCH --error=swin_gate_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=05:00:00
#SBATCH --partition=mig45g

# SWIN-B GATE: a dress rehearsal of the main jobs on 1-epoch runs. Run it before job_swin_ft_2.sh and
# job_swin_lora_2.sh (submit those with --dependency=afterok:<this job's id>).
#   1. verify-only for every swinb_* experiment (library-only check: trainable set = analytic count,
#      LoRA B=0 identity, merge/unmerge algebra; fails if the cluster's transformers/peft name the Swin
#      modules differently or the checkpoint loads partially)
#   2. 1-epoch training of the full-FT baseline and the most memory-hungry LoRA placement, through the
#      whole post-training path (test eval, batch-1 probe, adapter export, JSON)
#   3. the profiler (train at batch 1 and 64, inference) and the merge study (trained adapter, test-set
#      accuracy on a few batches), exactly as the main jobs call them
#   4. aggregate.py on all of it
#   5. tests/check_swin_gate.py: fails (exit 1) on anything that would make the main runs fail or give
#      wrong numbers (accuracy after 1 epoch, normalization, trainable count, memory headroom, profiler vs
#      training peak, merge exactness, aggregator assertions) and prints the expected main-job durations.
#      Only if everything passes does it write results_smoke/gate_certificate.json, which the main jobs
#      require for the exact code on disk.
# Everything goes to results_smoke*/ (never results/). Every gate run starts from scratch (the smoke folders
# are deleted first), so a resubmitted gate always rehearses the code that is on disk now.
# Runs from the directory you submit from: cd into VisionTransformer_2, then sbatch.
# Needs hf_vit/swin_base next to the other checkpoints (the registry falls back to the parent tree).
set -euo pipefail

FT=swinb_baseline_lr1e-4
LORA=swinb_lora_attn_mlp_r8

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd)"
$PY -c "import torch, transformers, peft; print('torch', torch.__version__, '| transformers', transformers.__version__, '| peft', peft.__version__)"

echo "=== 0. fresh start: removing earlier smoke outputs ==="
rm -rf results_smoke results_smoke_profile results_smoke_merge checkpoints_smoke

echo "=== 1. verify-only, every swinb_* experiment ==="
SWIN_EXPS="swinb_baseline_lr1e-5 swinb_baseline_lr3e-5 swinb_baseline_lr1e-4 swinb_lora_attn_r8 swinb_lora_mlp_r8 swinb_lora_attn_mlp_r8 swinb_lora_attn_r8_L0-11 swinb_lora_attn_r8_L12-23 swinb_lora_attn_r8_L0_2_4_6_8_10_12_14_16_18_20_22 swinb_lora_attn_r8_L1_3_5_7_9_11_13_15_17_19_21_23 swinb_baseline_lr3e-6 swinb_lora_attn_r8_lr3e-5 swinb_lora_attn_r8_lr3e-4 swinb_lora_attn_r8_lr1e-3"
$PY run.py --verify-only -s 42 -e $SWIN_EXPS

echo "=== 2. 1-epoch training (results_smoke/) ==="
for exp in $FT $LORA; do
  if [ -f "results_smoke/$exp/library_seed42.json" ]; then echo "skip $exp (smoke result exists)"; continue; fi
  $PY run.py -e "$exp" -s 42 --impl library --max-epochs 1 --results-dir results_smoke --checkpoint-dir checkpoints_smoke
done

echo "=== 3. profiler + merge study, as the main jobs call them (results_smoke_profile/, results_smoke_merge/) ==="
adapter="results_smoke/$LORA/library_seed42_adapter.pt"
for exp in $FT $LORA; do
  extra=""
  if [ "$exp" = "$LORA" ]; then extra="--adapter $adapter"; fi
  for mode in train inference; do
    out="results_smoke_profile/$exp/library_seed42_${mode}.json"
    if [ -f "$out" ]; then echo "skip $out"; continue; fi
    bs=""
    # 256 is there to exercise the out-of-memory path of the profiler on the real GPU (full FT likely
    # runs out of memory there); the main jobs run the full sweep 1..256.
    if [ "$mode" = "train" ]; then bs="--batch-sizes 1 64 256"; fi
    $PY profile_memory.py --experiment "$exp" --impl library --mode "$mode" --seed 42 $bs $extra --out results_smoke_profile
  done
done
if [ -f "results_smoke_merge/$LORA/seed42.json" ]; then echo "skip merge study"; else
  $PY merge_study.py --experiment "$LORA" --seed 42 --adapter "$adapter" --eval-test --eval-max-batches 4 \
      --cycles 3 --out results_smoke_merge
fi

echo "=== 4. aggregate.py on the smoke results ==="
$PY aggregate.py --arch swinb --results results_smoke --profile results_smoke_profile \
    --merge results_smoke_merge --out results_smoke/aggregate

echo "=== 5. pass/fail checks ==="
$PY tests/check_swin_gate.py
echo "GATE PASSED"
