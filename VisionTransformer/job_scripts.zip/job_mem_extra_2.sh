#!/bin/bash
#SBATCH --job-name=mem_extra_2
#SBATCH --output=mem_extra_2_%j.out
#SBATCH --error=mem_extra_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=02:00:00
#SBATCH --partition=mig45g

# EXTRA MEMORY PROFILES (2026-11-17). profile_memory.py in train mode only. NO TRAINING, so no gate: instead the
# job measures again configurations whose peaks are already known and fails if they differ (part C).
#   A. ViT-B attention LoRA on every block from k to 11, k = 0,1,2,3,4,5,6,8,10, batch sizes 1-256
#      -> results_mem_profile_vitb/   (needs the six new registry entries lora_attn_r8_L{1,2,4,5,8,10}-11)
#   B. full FT and the three LoRA targets of ViT-B and Swin-B at batch sizes 1, 2, 4, 8
#      -> results_mem_profile_bs/
#   C. check: A at k = 0, 3, 6 and B at batch 1 and 8 against the earlier measurements (tolerance 0.01 GiB)
# Library implementation, seed 42, perturbed-B adapter (peak memory does not depend on the adapter values).
# Rerun-safe: existing outputs are skipped. Run from the code folder:
#   VENV=<venv> ASSETS_ROOT=<folder holding hf_vit/ and cifar100/> sbatch job_mem_extra_2.sh
set -euo pipefail

EXPS_A="${EXPS_A:-lora_attn_r8 lora_attn_r8_L1-11 lora_attn_r8_L2-11 lora_attn_r8_L3-11 lora_attn_r8_L4-11 \
lora_attn_r8_L5-11 lora_attn_r8_L6-11 lora_attn_r8_L8-11 lora_attn_r8_L10-11}"
EXPS_B="${EXPS_B:-baseline lora_attn_r8 lora_mlp_r8 lora_attn_mlp_r8 \
swinb_baseline_lr1e-4 swinb_lora_attn_r8 swinb_lora_mlp_r8 swinb_lora_attn_mlp_r8}"
BS_A="${BS_A:-1 8 16 32 64 128 256}"
BS_B="${BS_B:-1 2 4 8}"
OUT_A="${OUT_A:-results_mem_profile_vitb}"
OUT_B="${OUT_B:-results_mem_profile_bs}"
DEVICE="${DEVICE:-}"          # empty = cuda; "cpu" only for a local dry run (memory fields are then 0)
CHECK="${CHECK:-1}"

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | ASSETS_ROOT=${ASSETS_ROOT:-unset}"
DEV_ARG=""; if [ -n "$DEVICE" ]; then DEV_ARG="--device $DEVICE"; fi

echo "=== 0. precautions: weights found, every experiment registered ==="
$PY - $EXPS_A $EXPS_B <<'EOF'
import sys, os
import experiments as e
for name, p in (("ViT-B", e.VIT_BASE_PATH), ("Swin-B", e.SWIN_BASE_PATH)):
    ok = os.path.isfile(os.path.join(p, "config.json"))
    print(f"{name} weights: {p} {'OK' if ok else 'MISSING'}")
    if not ok:
        sys.exit("weights not found: set ASSETS_ROOT to the folder that holds hf_vit/")
missing = [x for x in sys.argv[1:] if x not in e.EXPERIMENTS]
if missing:
    sys.exit(f"not registered: {missing} (copy the new experiments.py)")
print("all", len(set(sys.argv[1:])), "experiments registered")
EOF

run_set() {  # $1 = output folder, $2 = batch sizes, rest = experiments
  local out=$1 bs=$2; shift 2
  for exp in "$@"; do
    f="$out/$exp/library_seed42_train.json"
    if [ -f "$f" ]; then echo "skip $f"; continue; fi
    echo "--- $exp ($out)"
    $PY profile_memory.py --experiment "$exp" --impl library --mode train --seed 42 --batch-sizes $bs \
        --out "$out" $DEV_ARG
  done
}

echo "=== A. ViT-B, first adapted block k = 0..10 ==="
run_set "$OUT_A" "$BS_A" $EXPS_A
echo "=== B. batch sizes $BS_B ==="
run_set "$OUT_B" "$BS_B" $EXPS_B

echo "=== C. check against earlier measurements ==="
if [ "$CHECK" = "1" ]; then
$PY - "$OUT_A" "$OUT_B" <<'EOF'
import json, sys
out_a, out_b = sys.argv[1], sys.argv[2]
TOL = 0.01
def peaks(folder, exp):
    rows = json.load(open(f"{folder}/{exp}/library_seed42_train.json"))["train"]["sweep"]
    return {r["batch_size"]: (None if r["oom"] else r["peak_gb"]) for r in rows}
known_a = {"lora_attn_r8": 5.4587, "lora_attn_r8_L3-11": 4.2600, "lora_attn_r8_L6-11": 3.0610}   # batch 64
known_b = {"baseline": (1.6198, 1.8910), "lora_attn_r8": (0.4236, 0.9822), "lora_mlp_r8": (0.4512, 1.1787),
           "lora_attn_mlp_r8": (0.4660, 1.2621), "swinb_baseline_lr1e-4": (1.6382, 2.7082),
           "swinb_lora_attn_r8": (0.4952, 1.5104), "swinb_lora_mlp_r8": (0.5391, 1.8188),
           "swinb_lora_attn_mlp_r8": (0.5651, 1.9863)}                                         # batch 1, 8
bad = []
for exp, v in known_a.items():
    got = peaks(out_a, exp)[64]
    ok = got is not None and abs(got - v) <= TOL
    print(f"A {exp:24s} batch 64: {got:.4f} vs {v:.4f} {'OK' if ok else 'DIFFERENT'}"); bad += [] if ok else [exp]
for exp, (v1, v8) in known_b.items():
    p = peaks(out_b, exp)
    for bs, v in ((1, v1), (8, v8)):
        ok = p[bs] is not None and abs(p[bs] - v) <= TOL
        print(f"B {exp:24s} batch {bs}: {p[bs]:.4f} vs {v:.4f} {'OK' if ok else 'DIFFERENT'}"); bad += [] if ok else [exp]
    print(f"  {exp:24s} batch 2: {p[2]:.4f}  batch 4: {p[4]:.4f}")
for exp in sorted(k for k in __import__("os").listdir(out_a)):
    print(f"A {exp:24s} batch 64: {peaks(out_a, exp)[64]:.4f}")
if bad:
    sys.exit(f"CHECK FAILED for {sorted(set(bad))}")
print("CHECK PASSED")
EOF
fi
echo "MEM EXTRA DONE"
