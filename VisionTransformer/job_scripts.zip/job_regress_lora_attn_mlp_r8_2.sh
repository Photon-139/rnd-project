#!/bin/bash
#SBATCH --job-name=regress_attn_mlp_r8_2
#SBATCH --output=regress_attn_mlp_r8_2_%j.out
#SBATCH --error=regress_attn_mlp_r8_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=04:00:00
#SBATCH --partition=mig45g

# Regression: lora_attn_mlp_r8 seed 123, library + scratch (second config AND second seed). Compare with the original
# results/lora_attn_mlp_r8/*_seed123.json.
# Runs the REFACTORED code in the sibling folder VisionTransformer_2 (the original tree is
# untouched). It runs from the directory you submit from (SLURM_SUBMIT_DIR), so cd into VisionTransformer_2 and sbatch there.
set -euo pipefail

echo "Job ID : $SLURM_JOB_ID | Node : $SLURMD_NODENAME | Partition : $SLURM_JOB_PARTITION"
nvidia-smi -L
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
python3 --version

PROJECT_DIR="${PROJECT_DIR:-$SLURM_SUBMIT_DIR}"
cd "$PROJECT_DIR"
echo "Running from: $(pwd)"
echo
python3 run.py --experiment lora_attn_mlp_r8 --seeds 123 --impl paired --lr 1e-4
ls -la results/lora_attn_mlp_r8/
