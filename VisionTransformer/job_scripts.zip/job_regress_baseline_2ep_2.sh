#!/bin/bash
#SBATCH --job-name=regress_baseline_2ep_2
#SBATCH --output=regress_baseline_2ep_2_%j.out
#SBATCH --error=regress_baseline_2ep_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=02:00:00
#SBATCH --partition=mig45g

# Regression for the full fine-tuning path: baseline seed 42 truncated to 2 epochs (--max-epochs). Compare per-epoch
# train/val loss with epochs 1-2 of the original results/baseline/*_seed42.json. Written to results_ft_check/ so it can
# never be mistaken for a full run.
# Runs the REFACTORED code in the sibling folder VisionTransformer_2 (the original tree is
# untouched). It runs from the directory you submit from (SLURM_SUBMIT_DIR), so cd into VisionTransformer_2 and sbatch there.
set -euo pipefail

echo "Job ID : $SLURM_JOB_ID | Node : $SLURMD_NODENAME | Partition : $SLURM_JOB_PARTITION"
nvidia-smi -L
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
python3 --version

PROJECT_DIR="${PROJECT_DIR:-$SLURM_SUBMIT_DIR}"
cd "$PROJECT_DIR"
echo "Running from: $(pwd)"
echo
python3 run.py --experiment baseline --seeds 42 --impl paired --lr 1e-4 --max-epochs 2 --results-dir results_ft_check
ls -la results_ft_check/baseline/
