#!/bin/bash
#SBATCH --job-name=mem_sweep_2
#SBATCH --output=mem_sweep_2_%j.out
#SBATCH --error=mem_sweep_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=08:00:00
#SBATCH --partition=mig45g

# MEMORY SWEEP for the memory-budget study (profile_memory.py, train mode only). NO TRAINING.
# Peak training memory does not depend on the adapter values (ViT-B attention LoRA: perturbed random B and the
# trained adapter give the same peak, 5.4587 GiB at batch 64), so every configuration is profiled with the
# profiler's default perturbed-B adapter at seed 42: library implementation, batch sizes 1-256 (the sweep stops
# at the first out-of-memory batch size, which is recorded, e.g. ViT-L at 256).
# The predictions these measurements test were written before submission:
#   memory_model/fit_and_predictions_2026-11-10.txt (local)
#   0. precautions: the ViT-B gate certificate for this exact code (it hashes experiments.py and
#      profile_memory.py), then a smoke run of the first experiment at batch 1 and 8 into results_smoke_mem/
#   1. each experiment, one process each, into results_mem_profile/ (a new folder: no file names shared with
#      results_profile/ or results_v2_profile/)
# A failed experiment is reported and the job continues with the next one; the job exits non-zero at the end if
# any failed. Rerun-safe: existing outputs are skipped. Runs from the directory you submit from (VisionTransformer_2).
#   G=$(sbatch --parsable job_vitb_gate_2.sh); sbatch --dependency=afterok:$G job_memory_sweep_2.sh
set -euo pipefail

EXPS="${EXPS:-deitb_lora_attn_r8 deitb_lora_attn_r8_L1-11 deitb_lora_attn_r8_L2-11 deitb_lora_attn_r8_L3-11 \
deitb_lora_attn_r8_L4-11 deitb_lora_attn_r8_L5-11 deitb_lora_attn_r8_L6-11 deitb_lora_attn_r8_L8-11 \
deitb_lora_attn_r8_L10-11 \
vitl_lora_attn_r8 vitl_lora_attn_r8_L12-23 vitl_lora_mlp_r8 vitl_lora_attn_mlp_r8 \
swinb_lora_attn_r8_L2-23 swinb_lora_attn_r8_L4-23 swinb_lora_attn_r8_L8-23 swinb_lora_attn_r8_L16-23 \
swinb_lora_attn_r8_L22-23}"
OUT="${OUT:-results_mem_profile}"
SMOKE="${SMOKE:-results_smoke_mem}"

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS"

echo "=== 0. precautions: gate certificate for this exact code, existing outputs, smoke run ==="
$PY tests/check_vitb_gate.py --verify-certificate
$PY tests/check_vitb_gate.py --check-existing $EXPS --dirs no_results_dir $OUT no_merge_dir   # profiles only
first=$(echo $EXPS | awk '{print $1}')
$PY profile_memory.py --experiment "$first" --impl library --mode train --seed 42 --batch-sizes 1 8 \
    --out $SMOKE --overwrite

echo "=== 1. memory sweep (train mode, perturbed B, library) ==="
failed=""
for exp in $EXPS; do
  out="$OUT/$exp/library_seed42_train.json"
  if [ -f "$out" ]; then echo "skip $out"; continue; fi
  echo "--- $exp"
  if ! $PY profile_memory.py --experiment "$exp" --impl library --mode train --seed 42 --out $OUT; then
    echo "FAILED: $exp"
    failed="$failed $exp"
  fi
done

echo "MEMORY SWEEP DONE"
ls -la $OUT/*/ || true
if [ -n "$failed" ]; then echo "FAILED experiments:$failed"; exit 1; fi
