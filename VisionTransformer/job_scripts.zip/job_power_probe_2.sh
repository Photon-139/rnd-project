#!/bin/bash
#SBATCH --job-name=power_probe_2
#SBATCH --output=power_probe_2_%j.out
#SBATCH --error=power_probe_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=4G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=00:30:00
#SBATCH --partition=mig45g

# User-side checks of power/energy telemetry before asking the HPC administrator.
# Read-only: changes no GPU setting. Every check is allowed to fail; the job always finishes.
# For the shared-card check on mig90g (two 3g.90gb slices per card), submit twice with:
#   sbatch -p mig90g --gres=gpu:3g.90gb:1 job_power_probe_2.sh
# and compare the "parent GPU UUID" lines of the two jobs: equal = both slices of one card are ours.
set -uo pipefail

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
echo "=== nvidia-smi ==="
nvidia-smi -L
nvidia-smi -q -d POWER || true
nvidia-smi --query-gpu=index,uuid,power.draw,power.draw.average,power.draw.instant,power.limit --format=csv || true
nvidia-smi mig -lgi || true

echo "=== SLURM energy accounting ==="
scontrol show config 2>/dev/null | grep -i -E "AcctGatherEnergy|AcctGatherNodeFreq|JobAcctGather|AccountingStorageTRES|GresTypes" || echo "scontrol config not readable"
sacct -j "${SLURM_JOB_ID:-0}" --format=JobID,ConsumedEnergy,ConsumedEnergyRaw -P 2>/dev/null || echo "sacct not available on the compute node"

echo "=== DCGM ==="
if command -v dcgmi >/dev/null 2>&1; then
  dcgmi discovery -l || true
  dcgmi discovery -c || true   # MIG hierarchy
  # 155 = power usage, 156 = total energy, 1001 = GR engine active, 1002 = SM active, 1005 = DRAM active
  dcgmi dmon -e 155,156,1001,1002,1005 -c 5 || true
else
  echo "dcgmi not installed"
fi
pgrep -a nv-hostengine || echo "nv-hostengine not running (or not visible)"

echo "=== NVML probe + idle/load cycles ==="
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
python3 power_probe_2.py --out "power_probe_2_${SLURM_JOB_ID:-local}.json"

echo "=== who else is on the partitions right now ==="
squeue -p mig45g,mig90g -o "%.10i %.9P %.8u %.2t %.10M %b" 2>/dev/null || echo "squeue not available on the compute node"
echo "PROBE DONE"
