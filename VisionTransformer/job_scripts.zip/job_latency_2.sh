#!/bin/bash
#SBATCH --job-name=latency_2
#SBATCH --output=latency_2_%j.out
#SBATCH --error=latency_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=20:00:00
#SBATCH --partition=mig45g

# Prediction latency on real CIFAR-100 test images (latency_study.py). NO TRAINING: uses the
# trained seed-42 adapters already on disk (Swin-B: results/, ViT-B: results_v2/).
#   0. smoke: the first two experiments on 60 images, into results_smoke_latency/ (fails the job early)
#   1. GPU: each experiment, REPS separate processes; LoRA reps alternate which variant
#      (unmerged / merged) runs first. End-to-end batch 1 on all 10,000 test images,
#      batch-size sweep, CUDA-graph model-only timing.
#   2. CPU (edge proxy, CPU=1): one process per experiment, 200 images, 4 threads, no sweep
#      beyond batch 32.
# Rerun-safe: existing outputs are skipped. Missing adapters are an error, never a fallback.
# Swin-B placements trained later can be added with EXPS="..." sbatch job_latency_2.sh.
set -euo pipefail

REPS="${REPS:-3}"
CPU="${CPU:-1}"
EXPS="${EXPS:-swinb_baseline_lr1e-5 swinb_lora_attn_r8 swinb_lora_mlp_r8 swinb_lora_attn_mlp_r8 swinb_lora_attn_r8_L12-23 baseline lora_attn_r8 lora_attn_r8_L0-5 lora_attn_r8_L6-11 lora_attn_r8_L0_2_4_6_8_10 lora_attn_r8_L1_3_5_7_9_11}"
OUT="${OUT:-results_latency}"

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS | reps: $REPS | cpu: $CPU"

adapter_for() {  # prints the trained seed-42 adapter of a LoRA experiment, "" for full FT
  local exp="$1"
  case "$exp" in swinb_baseline*|baseline*) echo ""; return;; esac
  for d in results_v2 results; do
    if [ -f "$d/$exp/library_seed42_adapter.pt" ]; then echo "$d/$exp/library_seed42_adapter.pt"; return; fi
  done
  echo "MISSING"
}

echo "=== 0. precautions: every adapter exists, then a smoke run ==="
for exp in $EXPS; do
  a=$(adapter_for "$exp")
  if [ "$a" = "MISSING" ]; then echo "ERROR: no trained seed-42 adapter for $exp"; exit 1; fi
  echo "$exp -> ${a:-full fine-tuning (no adapter)}"
done
first=$(echo $EXPS | awk '{print $1}'); second=$(echo $EXPS | awk '{print $2}')
for exp in $first $second; do
  a=$(adapter_for "$exp")
  $PY latency_study.py --experiment "$exp" ${a:+--adapter "$a"} --n-e2e 60 --e2e-warmup 10 \
      --n-sweep 64 --batch-sizes 1 8 --out results_smoke_latency --overwrite
done

echo "=== 1. GPU ==="
for exp in $EXPS; do
  a=$(adapter_for "$exp")
  for rep in $(seq 1 "$REPS"); do
    out="$OUT/$exp/library_seed42_cuda_rep${rep}.json"
    if [ -f "$out" ]; then echo "skip $out"; continue; fi
    if [ $((rep % 2)) -eq 1 ]; then order=unmerged-first; else order=merged-first; fi
    $PY latency_study.py --experiment "$exp" ${a:+--adapter "$a"} --rep "$rep" --order "$order" --out "$OUT"
  done
done

if [ "$CPU" = "1" ]; then
  echo "=== 2. CPU (edge proxy) ==="
  for exp in $EXPS; do
    a=$(adapter_for "$exp")
    out="$OUT/$exp/library_seed42_cpu_rep1.json"
    if [ -f "$out" ]; then echo "skip $out"; continue; fi
    $PY latency_study.py --experiment "$exp" ${a:+--adapter "$a"} --device cpu --threads 4 \
        --n-e2e 200 --e2e-warmup 10 --n-sweep 256 --batch-sizes 1 8 32 --no-graph --out "$OUT"
  done
fi

echo "LATENCY DONE"
ls -la "$OUT"/*/ || true
