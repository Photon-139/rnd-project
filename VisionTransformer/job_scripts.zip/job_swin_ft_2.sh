#!/bin/bash
#SBATCH --job-name=swin_ft_2
#SBATCH --output=swin_ft_2_%j.out
#SBATCH --error=swin_ft_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=24:00:00
#SBATCH --partition=mig45g

# SWIN-B FULL FINE-TUNING (job A), library only. Submit with --dependency=afterok:<gate job id>; it also
# refuses to start unless results_smoke/gate_certificate.json certifies the code currently on disk.
# Everything the result needs is produced here, in one job:
#   1. memory profiler at seed 42 on the reference baseline (lr 1e-4, the swinb entry of
#      ARCH_BASELINE): train-step decomposition + batch-size sweep, and inference memory/latency
#      (results_profile/). Memory and latency depend on shapes, not on the learning rate, and not on
#      training, so it runs first.
#   2. training runs: lr 1e-5 and 1e-4 x seeds (results/<exp>/library_seed<N>.json)
# Rerun-safe: every (experiment, seed) whose result JSON exists is skipped, so resubmitting after a
# time-out continues where it stopped. Runs from the directory you submit from (VisionTransformer_2).
set -euo pipefail

SEEDS="${SEEDS:-42 123 456}"
EXPS="${EXPS:-swinb_baseline_lr1e-5 swinb_baseline_lr1e-4}"
PROFILE_EXP="swinb_baseline_lr1e-4"

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd) | experiments: $EXPS | seeds: $SEEDS"

echo "=== 0. precautions: gate certificate for this exact code, then verify-only ==="
$PY tests/check_swin_gate.py --verify-certificate
$PY tests/check_swin_gate.py --check-existing $EXPS
$PY run.py --verify-only -s 42 -e $EXPS

echo "=== 1. profiler (first: minutes, independent of training, so a time-out cannot lose it) (seed 42, $PROFILE_EXP) ==="
for mode in train inference; do
  out="results_profile/$PROFILE_EXP/library_seed42_${mode}.json"
  if [ -f "$out" ]; then echo "skip $out"; continue; fi
  $PY profile_memory.py --experiment "$PROFILE_EXP" --impl library --mode "$mode" --seed 42 --out results_profile
done

echo "=== 2. training ==="
for exp in $EXPS; do
  for seed in $SEEDS; do
    if [ -f "results/$exp/library_seed${seed}.json" ]; then echo "skip $exp seed $seed (result exists)"; continue; fi
    $PY run.py -e "$exp" -s "$seed" --impl library
  done
done

echo "FT DONE"
ls -la results/swinb_baseline_*/ results_profile/$PROFILE_EXP/ || true
