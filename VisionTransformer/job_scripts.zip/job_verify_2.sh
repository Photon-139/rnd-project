#!/bin/bash
#SBATCH --job-name=verify_2
#SBATCH --output=verify_2_%j.out
#SBATCH --error=verify_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=01:00:00
#SBATCH --partition=mig45g

# Gate check on the GPU for the refactor: paired-init + forward equivalence (plain and with non-zero LoRA B)
# for ViT-B (old and new experiments), then ViT-L, DeiT-B (paired like ViT-B) and Swin-B (library only: the
# gate there is models.library_only_checks). No training. ViT-B first so a missing weights directory for a
# later model cannot hide the ViT-B result.
# Runs the REFACTORED code in the sibling folder VisionTransformer_2 (the original tree is
# untouched). It runs from the directory you submit from (SLURM_SUBMIT_DIR), so cd into VisionTransformer_2 and sbatch there.
set -euo pipefail

echo "Job ID : $SLURM_JOB_ID | Node : $SLURMD_NODENAME | Partition : $SLURM_JOB_PARTITION"
nvidia-smi -L
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
python3 --version

PROJECT_DIR="${PROJECT_DIR:-$SLURM_SUBMIT_DIR}"
cd "$PROJECT_DIR"
echo "Running from: $(pwd)"
echo
python3 run.py --verify-only -s 42 -e baseline lora_attn_r8 lora_attn_mlp_r8 lora_attn_r8_L6-11 lora_qv_r8
echo "=== ViT-B verify OK; now ViT-L ==="
ls hf_vit/vit_large 2>/dev/null || echo "NOTE: ./hf_vit/vit_large not found next to the code (the absolute fallback path is used)"
python3 run.py --verify-only -s 42 -e vitl_baseline_lr1e-4 vitl_lora_attn_r8_L12-23
echo "=== ViT-L verify OK; now DeiT-B and Swin-B ==="
ls hf_vit/deit_base hf_vit/swin_base 2>/dev/null || echo "NOTE: ./hf_vit/deit_base or swin_base not found next to the code (the absolute fallback path is used)"
python3 run.py --verify-only -s 42 -e deitb_baseline_lr1e-4 deitb_lora_attn_r8_L6-11
python3 run.py --verify-only -s 42 -e swinb_baseline_lr1e-4 swinb_lora_attn_r8_L12-23 swinb_lora_attn_mlp_r8
echo "VERIFY DONE"
