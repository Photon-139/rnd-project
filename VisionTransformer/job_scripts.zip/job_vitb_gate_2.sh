#!/bin/bash
#SBATCH --job-name=vitb_gate_2
#SBATCH --output=vitb_gate_2_%j.out
#SBATCH --error=vitb_gate_2_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --gres=gpu:1g.45gb:1
#SBATCH --time=05:00:00
#SBATCH --partition=mig45g

# VIT-B GATE: a dress rehearsal of job_vitb_lora_2.sh on 1-epoch PAIRED runs (library + scratch), and of
# job_vitb_lr_2.sh (learning-rate check, library only) on 1-epoch runs at the lowest and highest new rates.
# Run it before the main jobs (submit those with --dependency=afterok:<this job's id>).
#   1. verify-only for every placement and learning-rate experiment (paired init, trainable set, forward
#      equivalence plain and with LoRA active)
#   2. 1-epoch paired training of all-blocks lora_attn_r8 (the reference, and the regression check against the
#      archived run) and the block subset lora_attn_r8_L6-11, through the whole post-training path (test eval,
#      batch-1 probe, adapter export, JSON)
#   2b. 1-epoch library-only training of baseline_lr3e-6 and lora_attn_r8_lr1e-3, as job_vitb_lr_2.sh calls it
#   3. the profiler (train at batch 1, 64 and 256, inference) for both implementations and the merge study
#      (trained adapter, test-set accuracy on a few batches), exactly as the main jobs call them
#   4. aggregate.py on all of it
#   5. tests/check_vitb_gate.py: fails (exit 1) on anything that would make the main runs fail or give wrong
#      numbers (pairing, accuracy after 1 epoch, normalization, trainable count, memory headroom, library vs
#      scratch memory, regression against the archive, profiler vs training peak, merge exactness, aggregator
#      assertions) and prints the expected main-job durations. Only if everything passes does it write
#      results_smoke_vitb/gate_certificate.json, which the main jobs require for the exact code on disk.
# Everything goes to results_smoke_vitb*/ (never results/). Every gate run starts from scratch (the smoke folders
# are deleted first), so a resubmitted gate always rehearses the code that is on disk now.
# Runs from the directory you submit from: cd into VisionTransformer_2, then sbatch.
set -euo pipefail

LORAS="lora_attn_r8 lora_attn_r8_L6-11"
LR_RUNS="baseline_lr3e-6 lora_attn_r8_lr1e-3"
SMOKE=results_smoke_vitb

echo "Job ID : ${SLURM_JOB_ID:-local} | Node : ${SLURMD_NODENAME:-local} | Partition : ${SLURM_JOB_PARTITION:-none}"
nvidia-smi -L || true
if [ -n "${VENV:-}" ]; then source "$VENV/bin/activate"; fi   # VENV unset: use the current Python environment
PY="${PY:-python3}"
cd "${PROJECT_DIR:-${SLURM_SUBMIT_DIR:-$PWD}}"
echo "Running from: $(pwd)"
$PY -c "import torch, transformers, peft; print('torch', torch.__version__, '| transformers', transformers.__version__, '| peft', peft.__version__)"

echo "=== 0. fresh start: removing earlier smoke outputs ==="
rm -rf $SMOKE ${SMOKE}_profile ${SMOKE}_merge checkpoints_smoke_vitb

echo "=== 1. verify-only, every placement experiment ==="
PLACEMENT_EXPS="lora_attn_r8 lora_attn_r8_L0-5 lora_attn_r8_L6-11 lora_attn_r8_L0_2_4_6_8_10 lora_attn_r8_L1_3_5_7_9_11"
LR_EXPS="baseline_lr3e-6 baseline_lr1e-5 lora_attn_r8_lr3e-5 lora_attn_r8_lr3e-4 lora_attn_r8_lr1e-3"
$PY run.py --verify-only -s 42 -e $PLACEMENT_EXPS $LR_EXPS

echo "=== 2. 1-epoch paired training ($SMOKE/) ==="
for exp in $LORAS; do
  $PY run.py -e "$exp" -s 42 --impl paired --max-epochs 1 --results-dir $SMOKE --checkpoint-dir checkpoints_smoke_vitb
done

echo "=== 2b. 1-epoch library-only training, as job_vitb_lr_2.sh calls it ($SMOKE/) ==="
for exp in $LR_RUNS; do
  $PY run.py -e "$exp" -s 42 --impl library --max-epochs 1 --results-dir $SMOKE --checkpoint-dir checkpoints_smoke_vitb
done

echo "=== 3. profiler + merge study, as the main jobs call them (${SMOKE}_profile/, ${SMOKE}_merge/) ==="
for exp in $LORAS; do
  for impl in library scratch; do
    adapter="$SMOKE/$exp/${impl}_seed42_adapter.pt"
    for mode in train inference; do
      bs=""
      # 256 is the top of the main jobs' sweep (1..256); an out-of-memory there is recorded, not fatal.
      if [ "$mode" = "train" ]; then bs="--batch-sizes 1 64 256"; fi
      $PY profile_memory.py --experiment "$exp" --impl "$impl" --mode "$mode" --seed 42 $bs \
          --adapter "$adapter" --out ${SMOKE}_profile
    done
  done
  $PY merge_study.py --experiment "$exp" --seed 42 --adapter "$SMOKE/$exp/library_seed42_adapter.pt" --eval-test \
      --eval-max-batches 4 --cycles 3 --out ${SMOKE}_merge
done

echo "=== 4. aggregate.py on the smoke results ==="
$PY aggregate.py --arch vitb --results $SMOKE --profile ${SMOKE}_profile --merge ${SMOKE}_merge --out $SMOKE/aggregate

echo "=== 5. pass/fail checks ==="
$PY tests/check_vitb_gate.py
echo "GATE PASSED"
